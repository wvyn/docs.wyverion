import { jsonCache, newClient, readJson } from "./main";
import configs from "./configs";
import axios from "axios"

import { EmbedBuilder, SlashCommandBuilder } from "@discordjs/builders";
import { ActivityType, CacheType, ChatInputCommandInteraction, MessageContextMenuCommandInteraction, UserContextMenuCommandInteraction } from "discord.js";
import { writeFileSync } from "fs";
import { resolve } from "path";

const commands = [
    new SlashCommandBuilder()
        .setName("verify")
        .setDescription("Verify in the FORCE Community.")
        .addStringOption(option => option.setName("user").setDescription("Your Roblox Username or UserId").setRequired(true))
].map(command => command.toJSON());

export default async () => {
    const client = await newClient(configs.VerificationBotToken)

    client.user?.setPresence({ activities: [{ name: "Information", url: "https://wyverion.com", type: ActivityType.Streaming }] })

    try {
        client.application?.commands.set(commands)
        //client.guilds.cache.get("1357895350077362306")?.commands.set(commands)
        console.log('Commands have been registered.')
    } catch (error) {
        console.error('Error registering commands:', error);
    }

    async function verify(interaction: ChatInputCommandInteraction<CacheType> | MessageContextMenuCommandInteraction<CacheType> | UserContextMenuCommandInteraction<any>, data: any) {
        const response = await axios.get(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${data.id}&size=420x420&format=Png&isCircular=false`)

        const words = [
            "wyvern", "blue", "water", "orange", "yellow", "over", "awesome", "fellow", "nice",
            "good", "tree", "park", "car", "hill", "mountain", "green", "truck", "apple", "the",
            "turbine", "fan", "shoe", "horse", "dog", "cat", "house", "home", "boots", "and", "engine",
            "plane", "grass", "clean", "train", "bunny", "moon", "sun", "food", "ice", "snow", "sand"
        ]

        const sentence: string[] = [];
        for (let i = 0; i < 12; i++) {
            const randomIndex = Math.floor(Math.random() * words.length);
            sentence.push(words[randomIndex]);
        }

        {
            const pendingJson = readJson(resolve("JSONCloud/PendingVerification.json"))
            pendingJson[interaction.user.id] = String(data.id)
            writeFileSync(resolve("JSONCloud/PendingVerification.json"), JSON.stringify(pendingJson))
            jsonCache.set(resolve("JSONCloud/PendingVerification.json"), pendingJson)
        }

        const imageUrl = response.data.data[0].imageUrl
        const verificationPhrase = sentence.join(" ");
        await interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setTitle("Verification using Game")
                    .setThumbnail(imageUrl)
                    .setDescription(`Hello, **${data.displayName}**! To verify your identity join the game below.\nhttps://www.roblox.com/games/80395454464449`),
                new EmbedBuilder()
                    .setTitle("Verification using Profile")
                    .addFields(
                        { name: "Verification Phrase", value: "```" + verificationPhrase + "```" },
                    )
                    .setDescription(`Or put this phrase on your **[Roblox Profile's](https://www.roblox.com/users/profile)** **About Me**.`)
                    .setFooter({
                        text: "Wyverion",
                        iconURL: "https://cdn.discordapp.com/attachments/1134354380611657769/1358037744328114339/WyvernBlack.png?ex=67f262b5&is=67f11135&hm=a6daa6f84542575723f871466b7aeb46e94f989224fdc72ac75f9f31cbbe48fb&"
                    })
            ]
        });

        const interval = setInterval(async () => {
            const response = await axios.get(`https://users.roblox.com/v1/users/${data.id}`)
            if (response.status == 200) {
                const data = response.data
                let editInteraction = false
                if (readJson(resolve("JSONCloud/Verification.json"))[String(data.id)]) {
                    editInteraction = true
                }
                if (data.description.includes(verificationPhrase)) {
                    const json = readJson(resolve("JSONCloud/Verification.json"))
                    json[String(data.id)] = interaction.user.id
                    writeFileSync(resolve("JSONCloud/Verification.json"), JSON.stringify(json))
                    jsonCache.set(resolve("JSONCloud/Verification.json"), json)
                    editInteraction = true
                }
                if (editInteraction) {
                    const pendingJson = readJson(resolve("JSONCloud/PendingVerification.json"))
                    delete pendingJson[interaction.user.id]
                    writeFileSync(resolve("JSONCloud/PendingVerification.json"), JSON.stringify(pendingJson))
                    jsonCache.set(resolve("JSONCloud/PendingVerification.json"), pendingJson)

                    clearInterval(interval)
                    interaction.editReply({
                        embeds: [
                            new EmbedBuilder()
                                .setTitle("Verified")
                                .setColor(0x00d60e)
                                .setThumbnail(imageUrl)
                                .setDescription(`Thank you for verifying, **${data.displayName}**`)
                                .setFooter({
                                    text: "Wyverion",
                                    iconURL: "https://cdn.discordapp.com/attachments/1134354380611657769/1358037744328114339/WyvernBlack.png?ex=67f262b5&is=67f11135&hm=a6daa6f84542575723f871466b7aeb46e94f989224fdc72ac75f9f31cbbe48fb&"
                                })
                        ]
                    })
                }
            }
        }, 1000)

        setTimeout(() => {
            const pendingJson = readJson(resolve("JSONCloud/PendingVerification.json"))
            if (pendingJson[interaction.user.id]) {
                delete pendingJson[interaction.user.id]
                writeFileSync(resolve("JSONCloud/PendingVerification.json"), JSON.stringify(pendingJson))
                jsonCache.set(resolve("JSONCloud/PendingVerification.json"), pendingJson)
            }
            clearInterval(interval)
        }, 120 * 1000)
    }

    client.on('interactionCreate', async interaction => {
        if (!interaction.isCommand()) return;
        const { commandName } = interaction;

        if (commandName === 'verify') {
            try {
                const user = interaction.options.get("user", true).value
                if (Number(user)) {
                    const response = await axios.get(`https://users.roblox.com/v1/users/${user}`)
                    if (response.status == 200) {
                        const data = response.data
                        verify(interaction, data)
                    }
                } else {
                    const response = await axios.post(`https://users.roblox.com/v1/usernames/users/`, {
                        usernames: [user]
                    })
                    if (response.status == 200) {
                        const data = response.data.data[0]
                        if (data) {
                            verify(interaction, data)
                        } else {
                            await interaction.reply('give me a real username or userid');
                        }
                    }
                }
            } catch (error) {
                console.error(error)
                await interaction.reply('An error occurred');
            }
        }
    });
}