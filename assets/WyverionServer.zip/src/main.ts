import { Client, ClientUser, Events, GatewayIntentBits, Guild, Role, TextChannel, User, EmbedBuilder, Message, DMChannel } from 'discord.js';
import express, { Response } from "express"
import configs from './configs';
import { existsSync, readFileSync, unlinkSync, writeFileSync } from 'fs';
import { resolve } from 'path';
import { Request } from 'express-serve-static-core';
import verificationBot from './verificationBot';

const app = express()
app.use(express.json());

const clients: { [key: string]: Client } = {}
app.get("/", (req, res) => {
    res.json({ message: "Wyverion Discord Client" })
})

function getUserInfo(user: ClientUser | User) {
    return {
        accentColor: user.accentColor,
        bot: user.bot,
        avatar: user.avatar,
        tag: user.tag,
        verified: user instanceof ClientUser && user.verified || undefined,
        avatarURL: user.avatarURL,
        displayAvatarURL: user.displayAvatarURL,
        mfaEnabled: user instanceof ClientUser && user.mfaEnabled || undefined,
        displayName: user.displayName,
        username: user.username,
        id: user.id
    }
}

async function newClient(token: string) {
    return new Promise<Client>((resolve, reject) => {
        const client = new Client({ intents: [GatewayIntentBits.Guilds] });
        
        client.on(Events.ClientReady, () => {
            resolve(client)
        })
    
        clients[token] = client
        client.login(token)
    })
}

app.post("/client", async (req, res) => {
    const { Authentication, Token } = req.body
    if (Authentication == configs.AuthenticationDiscord && Token) {
        if (clients[Token]) {
            res.json({ user: getUserInfo((await newClient(Token)).user as ClientUser) })
        } else {
            res.json({ user: getUserInfo((await newClient(Token)).user as ClientUser) })
        }
        return
    }

    res.json({ success: false, response: "Access denied." })
})

app.post("/client/close", async (req, res) => {
    const { Authentication, Token } = req.body
    if (Authentication == configs.AuthenticationDiscord && Token) {
        const client = clients[Token]
        if (client) {
            const user = client.user
            await client.destroy()
            res.json({ user: getUserInfo(user as ClientUser) })
        } else {
            res.json({ success: false, response: "No client?"})
        }
        return
    }

    res.json({ success: false, response: "Access denied." })
})

function getGuildInfo(guild: Guild) {
    return {
        id: guild.id,
        afkChannelId: guild.afkChannelId,
        approximateMemberCount: guild.approximateMemberCount,
        approximatePresenceCount: guild.approximatePresenceCount,
        createdTimestamp: guild.createdTimestamp,
        description: guild.description,
        icon: guild.icon,
        iconURL: guild.iconURL,
        joinedTimestamp: guild.joinedTimestamp,
        ownerId: guild.ownerId,
        name: guild.name,
        nameAcronym: guild.nameAcronym
    }
} 

app.post("/guild", async (req, res) => {
    const { Authentication, Token, guildId } = req.body
    if (Authentication == configs.AuthenticationDiscord && Token  && guildId) {
        const client = clients[Token]
        if (client) {
            const guild = client.guilds.cache.get(guildId)
            if (guild) {
                res.json({ guild: getGuildInfo(guild) })
            } else {
                res.json({ success: false, response: "No guild." })
            }
        } else {
            res.json({ success: false, response: "No client." })
        }
        return
    }

    res.json({ success: false, response: "Access denied." })
})

app.post("/user", async (req, res) => {
    const { Authentication, Token, userId } = req.body
    if (Authentication == configs.AuthenticationDiscord && Token && userId) {
        const client = clients[Token]
        if (client) {
            const user = await client.users.fetch(userId)
            if (user) {
                res.json({ user: getUserInfo(user) })
            } else {
                res.json({ success: false, response: "No user." })
            }
        } else {
            res.json({ success: false, response: "No client." })
        }
        return
    }

    res.json({ success: false, response: "Access denied." })
})

function getRoleInfo(role: Role) {
    return {
        color: role.color,
        createdTimestamp: role.createdTimestamp,
        hexColor: role.hexColor,
        id: role.id,
        icon: role.icon,
        iconURL: role.iconURL,
        name: role.name,
        position: role.position
    }
}

app.post("/guild/role/add", async (req, res) => {
    const { Authentication, Token, guildId, userId, roleId } = req.body
    if (Authentication == configs.AuthenticationDiscord && Token && guildId && userId && roleId) {
        const client = clients[Token]
        if (client) {
            const guild = client.guilds.cache.get(guildId)
            const member = await guild?.members.fetch(userId)
            const role = await guild?.roles.fetch(roleId)
            if (guild && member && role) {
                member.roles.add(role)
                res.json({ role: getRoleInfo(role) })
            } else {
                res.json({ success: false, response: "No user or guild." })
            }
        } else {
            res.json({ success: false, response: "No client." })
        }
        return
    }

    res.json({ success: false, response: "Access denied." })
})

app.post("/guild/role/remove", async (req, res) => {
    const { Authentication, Token, guildId, userId, roleId } = req.body
    if (Authentication == configs.AuthenticationDiscord && Token && guildId && userId && roleId) {
        const client = clients[Token]
        if (client) {
            const guild = client.guilds.cache.get(guildId)
            const member = await guild?.members.fetch(userId)
            const role = await guild?.roles.fetch(roleId)
            if (guild && member && role) {
                member.roles.remove(role)
                res.json({ role: getRoleInfo(role) })
            } else {
                res.json({ success: false, response: "No user or guild." })
            }
        } else {
            res.json({ success: false, response: "No client." })
        }
        return
    }

    res.json({ success: false, response: "Access denied." })
})

function getChannelInfo(channel: TextChannel) {
    return {
        id: channel.id,
        name: channel.name,
        type: channel.type,
        topic: channel.topic,
        createdTimestamp: channel.createdTimestamp,
        isTextBased: channel.isTextBased(),
        isVoiceBased: channel.isVoiceBased(),
        isThread: channel.isThread(),
        position: channel.position,
        guildId: channel.guildId
    }
}

app.post("/channel", async (req, res) => {
    const { Authentication, Token, channelId } = req.body
    if (Authentication == configs.AuthenticationDiscord && Token && channelId) {
        const client = clients[Token]
        if (client) {
            const channel = await client.channels.fetch(channelId)
            if (channel && channel.isTextBased()) {
                res.json({ channel: getChannelInfo(channel as TextChannel) })
            } else {
                res.json({ success: false, response: "No channel found or it's not a text channel." })
            }
        } else {
            res.json({ success: false, response: "No client." })
        }
        return
    }

    res.json({ success: false, response: "Access denied." })
})

function GetMessageInfo(message: Message) {
    return {
        author: getUserInfo(message.author),
        channelId: message.channelId,
        cleanContent: message.cleanContent,
        content: message.content,
        createdTimestamp: message.createdTimestamp,
        id: message.id,
        hasThread: message.hasThread,
        guildId: message.guildId,
        position: message.position,
        pinned: message.pinned
    }
}

function buildEmbed(embed: any) {
    let embedBuild = new EmbedBuilder()
    if (embed.title) embedBuild.setTitle(embed.title);
    if (embed.description) embedBuild.setDescription(embed.description);
    if (embed.color) embedBuild.setColor(embed.color);
    if (embed.timestamp) embedBuild.setTimestamp(embed.timestamp == true && new Date() || embed.timestamp);
    if (embed.author) embedBuild.setAuthor(embed.author);
    if (embed.url) embedBuild.setURL(embed.url);
    if (embed.thumbnail) embedBuild.setThumbnail(embed.thumbnail);
    if (embed.fields) embedBuild.addFields(...embed.fields);
    if (embed.image) embedBuild.setImage(embed.image);
    if (embed.footer) embedBuild.setFooter(embed.footer);

    return embedBuild
}

app.post("/channel/message/send", async (req, res) => {
    const { Authentication, Token, channelId, content = "", embeds } = req.body

    if (Authentication == configs.AuthenticationDiscord && Token && channelId && content != null) {
        const client = clients[Token]
        if (client) {
            const channel = await client.channels.fetch(channelId)
            if (channel && channel.isTextBased()) {
                const textChannel = channel as TextChannel

                const embedBuild: any[] = []
                if (embeds) {
                    for (let embed of embeds) {
                        embedBuild.push(buildEmbed(embed))
                    }
                }

                try {
                    const message = await textChannel.send({
                        content,
                        embeds: embedBuild
                    })
                    res.json({ success: true, message: GetMessageInfo(message) })
                } catch (error) {
                    res.json({ success: false, response: `Failed to send message. ${error}` })
                }
            } else {
                res.json({ success: false, response: "No valid text channel." })
            }
        } else {
            res.json({ success: false, response: "No client." })
        }
        return
    }

    res.json({ success: false, response: "Access denied." })
})

app.post("/guild/channels", async (req, res) => {
    const { Authentication, Token, guildId } = req.body
    if (Authentication == configs.AuthenticationDiscord && Token && guildId) {
        const client = clients[Token];
        if (client) {
            const guild = client.guilds.cache.get(guildId)
            if (guild) {
                const channels = await guild.channels.fetch()
                const textChannels = channels
                    .filter(c => c?.isTextBased())
                    .map(c => getChannelInfo(c as TextChannel))

                res.json({ channels: textChannels });
            } else {
                res.json({ success: false, response: "No guild." })
            }
        } else {
            res.json({ success: false, response: "No client." })
        }
        return;
    }

    res.json({ success: false, response: "Access denied." })
})

app.post("/client/guilds", async (req, res) => {
    const { Authentication, Token } = req.body
    if (Authentication == configs.AuthenticationDiscord && Token) {
        const client = clients[Token]
        if (client) {
            const guilds = client.guilds.cache.map(g => getGuildInfo(g))
            res.json({ guilds: guilds })
        } else {
            res.json({ success: false, response: "No client." })
        }
        return
    }

    res.json({ success: false, response: "Access denied." })
})

app.post("/guild/roles", async (req, res) => {
    const { Authentication, Token, guildId } = req.body
    if (Authentication == configs.AuthenticationDiscord && Token && guildId) {
        const client = clients[Token]
        if (client) {
            const guild = client.guilds.cache.get(guildId)
            if (guild) {
                const roles = await guild.roles.fetch()
                const roleData = roles.map(role => getRoleInfo(role))
                res.json({ roles: roleData })
            } else {
                res.json({ success: false, response: "No guild." })
            }
        } else {
            res.json({ success: false, response: "No client." })
        }
        return
    }

    res.json({ success: false, response: "Access denied." })
})

app.post("/channel/message/get", async (req, res) => {
    const { Authentication, Token, channelId, messageId } = req.body
    if (Authentication == configs.AuthenticationDiscord && Token && channelId && messageId) {
        const client = clients[Token]
        if (client) {
            const channel = await client.channels.fetch(channelId) as DMChannel
            if (channel && channel.isTextBased()) {
                try {
                    const message = await channel.messages.fetch(messageId)
                    res.json({ message: GetMessageInfo(message) })
                } catch (error) {
                    res.json({ success: false, response: error })
                }
            } else {
                res.json({ success: false, response: "No channel found or it's not a text channel." })
            }
        } else {
            res.json({ success: false, response: "No client." })
        }
        return
    }

    res.json({ success: false, response: "Access denied." })
})

app.post("/channel/message/delete", async (req, res) => {
    const { Authentication, Token, channelId, messageId } = req.body
    if (Authentication == configs.AuthenticationDiscord && Token && channelId && messageId) {
        const client = clients[Token]
        if (client) {
            const channel = await client.channels.fetch(channelId) as DMChannel
            if (channel && channel.isTextBased()) {
                try {
                    const message = await channel.messages.fetch(messageId)
                    await message.delete()
                    res.json({ message: GetMessageInfo(message) })
                } catch (error) {
                    res.json({ success: false, response: error })
                }
            } else {
                res.json({ success: false, response: "No channel found or it's not a text channel." })
            }
        } else {
            res.json({ success: false, response: "No client." })
        }
        return
    }

    res.json({ success: false, response: "Access denied." })
})

app.post("/user/send", async (req, res) => {
    const { Authentication, Token, userId, content, embeds } = req.body

    if (Authentication == configs.AuthenticationDiscord && Token && userId && content) {
        const client = clients[Token]
        if (client) {
            const user = await client.users.fetch(userId)
            if (user) {
                const embedBuild: any[] = []
                if (embeds) {
                    for (let embed of embeds) {
                        embedBuild.push(buildEmbed(embed))
                    }
                }

                try {
                    const message = await user.send({
                        content,
                        embeds: embedBuild
                    })
                    res.json({ success: true, message: GetMessageInfo(message) })
                } catch (error) {
                    res.json({ success: false, response: "Failed to send message." })
                }
            } else {
                res.json({ success: false, response: "No valid user." })
            }
        } else {
            res.json({ success: false, response: "No client." })
        }
        return
    }

    res.json({ success: false, response: "Access denied." })
})

function validateRequest(req: Request, res: Response, requiredFields: string[] = []) {
    const { Authentication, name } = req.body
    if (Authentication !== configs.AuthenticationJSONCloud || !name || (requiredFields.length && requiredFields.some(field => !req.body[field]))) {
        res.json({ success: false, response: "Access denied." })
        return false
    }

    const filePath = resolve(`JSONCloud/${name}.json`)
    if (!existsSync(filePath)) {
        res.json({ success: false, response: "File not found." })
        return false
    }

    return filePath
}

writeFileSync(resolve("JSONCloud/PendingVerification.json"), "{}")

const jsonCache = new Map()
function readJson(filePath: string) {
    if (jsonCache.has(filePath)) {
        return jsonCache.get(filePath)
    }

    const data = JSON.parse(readFileSync(filePath, 'utf8'))
    jsonCache.set(filePath, data)
    return data
}

app.post("/json/load", (req, res) => {
    const { name } = req.body
    const filePath = resolve(`JSONCloud/${name}.json`)

    if (!existsSync(filePath)) {
        writeFileSync(filePath, "{}")
        res.json({ loaded: true, created: true })
        return
    }

    res.json({ loaded: true })
})

app.post("/json/write", (req, res) => {
    const { name, data } = req.body
    const filePath = validateRequest(req, res, ['data'])
    if (!filePath) return

    writeFileSync(filePath, data)
    jsonCache.set(filePath, JSON.parse(data))
    res.json({ success: true })
})

app.post("/json/read", (req, res) => {
    const { name } = req.body
    const filePath = validateRequest(req, res)
    if (!filePath) return

    const json = readJson(filePath)
    res.json(json)
})

app.post("/json/get", (req, res) => {
    const { name, index } = req.body
    const filePath = validateRequest(req, res, ['index'])
    if (!filePath) return

    const json = readJson(filePath)
    res.json({ data: json[index] })
})

app.post("/json/push", (req, res) => {
    const { name, data } = req.body
    const filePath = validateRequest(req, res, ['data'])
    if (!filePath) return

    const json = readJson(filePath)
    json.push(data)
    writeFileSync(filePath, JSON.stringify(json))
    jsonCache.set(filePath, json)
    res.json({ success: true })
})

app.post("/json/update", (req, res) => {
    const { name, index, value } = req.body
    const filePath = validateRequest(req, res, ['index', 'value'])
    if (!filePath) return

    const json = readJson(filePath)
    json[index] = value
    writeFileSync(filePath, JSON.stringify(json))
    jsonCache.set(filePath, json)
    res.json({ success: true })
})

app.post("/json/remove", (req, res) => {
    const { name, index } = req.body
    const filePath = validateRequest(req, res, ['index'])
    if (!filePath) return

    const json = readJson(filePath)
    delete json[index]
    writeFileSync(filePath, JSON.stringify(json))
    jsonCache.set(filePath, json)
    res.json({ success: true })
})

app.post("/json/delete", (req, res) => {
    const { name } = req.body
    const filePath = validateRequest(req, res)
    if (!filePath) return

    unlinkSync(filePath)
    jsonCache.delete(filePath)
    res.json({ success: true })
})

app.post("/json/find", (req, res) => {
    const { name, value } = req.body
    const filePath = validateRequest(req, res, ['value'])
    if (!filePath) return

    const json = readJson(filePath)
    for (let key in json) {
        if (json[key] === value) {
            res.json({ key: key })
            return
        }
    }

    res.json({ success: false, response: "No key found for the given value." })
})

app.listen(configs.Port, () => {
    console.log("Wyverion Discord Hosted at 127.0.0.1:3000")
})

export { app, clients, newClient, readJson, jsonCache }
verificationBot()