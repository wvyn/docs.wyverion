import yaml from "yaml";
import { readFileSync } from "fs";
import { resolve } from "path"

interface Configs {
    Port: number
    AuthenticationDiscord: string
    VerificationBotToken: string
    AuthenticationJSONCloud: string
}

const configs: Configs = yaml.parse(readFileSync(resolve("configs.yaml"), "ascii"))

export default configs